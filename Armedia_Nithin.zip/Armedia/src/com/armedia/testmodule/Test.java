package com.armedia.testmodule;

public class Test {
	public static void main(String args[]){
		Module module= new Module();
		module.inputfile();
	
		}
}
