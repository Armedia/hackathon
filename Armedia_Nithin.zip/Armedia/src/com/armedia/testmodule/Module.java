package com.armedia.testmodule;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Module {
	private ArrayList<String> controlIndex;
	private ArrayList<String> dataValues;
	

	public ArrayList<String> getControlIndex() {
		return controlIndex;
	}

	public void setControlIndex(ArrayList<String> controlIndex) {
		this.controlIndex = controlIndex;
	}

	public ArrayList<String> getDataValues() {
		return dataValues;
	}

	public void setDataValues(ArrayList<String> dataValues) {
		this.dataValues = dataValues;
	}
	
	public void inputfile(){
		FileReader fileReader=null;
		try {
			fileReader = new FileReader("C:/Users/Nithin/Desktop/Hackathon/Input.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader read= new BufferedReader(fileReader);
		String str;
		String str1;
		int index;
		try {
			while ((str = read.readLine())!=null){
				if(str.startsWith("*")){
					System.out.println(str);
					
				}
			
}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
}
