import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class problem {

	// helper func
	public static int[] str2intArr(String s ) {
		String[] a = s.split(" ");
		int[] res = new int[a.length];
		for(int i = 0; i < a.length; i ++) {
			res[i] = Integer.parseInt(a[i]);
		}
		return res;
	}

	public static void main(String[] args) {
		
		// declaring constants and map
		final double PI    = 3.14;
		final double PSI   = 6.48485;     
		final double ZETA  = 3.2;

		HashMap<String, Double> map = new HashMap<String, Double>();
		map.put("a", 3.1);
		map.put("b", 4.1);
		map.put("c",6.0);

		FileReader f;
		try {
			// getting file input
			f = new FileReader("test.txt");
			BufferedReader ff = new BufferedReader(f);
			Scanner scan = new Scanner(ff);
			
			// number of control groups
			int num = scan.nextInt();
			int control = 0;
			
			int[] intArr = new int[2];
			String line;
			while( control < num) {
				try {
					line = scan.nextLine();
				}catch(NoSuchElementException e) {
					// short control groups
					break;
				}
				if(line.startsWith("*")) { // is a control group
					control++;  // add one to the control group counter
					line = line.substring(1, 4);	
					intArr = str2intArr(line);

					// intArr now contains the control integers on the line
					// intArr[0] is number of data entries
					// intArr[1] is number of elements in them
					double result;
					// = pi * (first value) + psi * (second value)^3 + ( zeta^(lookup using the following mapping)) / (second value) 
					
					if(intArr[1] == 3) { // we must process
						String ints;
						for(int j = 0; j < intArr[0]; j++) {
							String next = scan.nextLine(); // get the entry
							try {
								ints = next.substring(0, 3);
								int[] entryInts = str2intArr(ints);
								Double let = map.get(next.substring(4,5));
								if(let == null) // if letter cannot be translated: assume a
									let = 3.1;
								// calculate result and display
								result = PI * entryInts[0] + PSI * Math.pow(entryInts[1], 3) + Math.pow(ZETA, let) / entryInts[1];
								System.out.printf("FORM 33 = %.3f\n", result);
							}catch(Exception e) {
								// bad entry
							}
						}
					}
				}
			}
			scan.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found.");
			e.printStackTrace();
		}
	}

}
