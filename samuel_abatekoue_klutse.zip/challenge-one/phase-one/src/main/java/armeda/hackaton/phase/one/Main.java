package armeda.hackaton.phase.one;

public class Main {
    public static void main(String[] args) {
        DataProcessor.process(DataProcessor.readStocks());
    }



}
