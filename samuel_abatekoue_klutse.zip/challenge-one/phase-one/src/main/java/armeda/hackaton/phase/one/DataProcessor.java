package armeda.hackaton.phase.one;

import lombok.Data;
import lombok.NoArgsConstructor;
import tg.klutse.samuel.java.utils.base.BaseUtils;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class DataProcessor {

    public static List<String> readStocks() {
        ArrayList<String> data = new ArrayList<>();
        BaseUtils.readFromFile(BaseUtils.getFileFromResources(DataProcessor.class, "data/data")).forEach(s -> {
            data.add(s);
        });
        return data;
    }

    public static void process(List<String> data) {
        if (data != null && !data.isEmpty()) {
            Integer n = Integer.parseInt(data.get(0));
            int set = 0;
            System.out.println(n + " datasets");
            List<Report> reports = new ArrayList<>();
            for (int i = 1; i < data.size(); i++) {
                String s = data.get(i);
                if (s.startsWith("*")) {
                    Report r = new Report();
                    StringTokenizer sT = new StringTokenizer(s.replace("*", ""));
                    Integer size = Integer.parseInt(sT.nextToken());
                    Integer numberOfElements = Integer.parseInt(sT.nextToken());
                    r.setControlRecord(size + " " + numberOfElements);
                    if (numberOfElements.equals(3)) {
                        r.setDataSet(data.subList(i + 1, i + 1 + size));
                        r = processDataSet(r,data.subList(i + 1, i + 1 + size));
                    } else {
                        r.setResults(new ArrayList<>());
                        r.getResults().add("Invalid Dataset");
                    }
                    reports.add(r);
                }
//                System.out.println(data.get(i));
            }
            reports.forEach(System.out::println);
        }
    }

    public static Report processDataSet(Report report, List<String> subdata) {
        Double a = 3.1, b = 4.1, c = 6.0;
        Double pi = 3.14, psi = 6.48485, zeta = 3.2;
        List<Double> results = new ArrayList<>();
        report.setResults(new ArrayList<>());
        for (String s : subdata) {
            StringTokenizer sT = new StringTokenizer(s);
            int i = 0;
            if (sT.countTokens() == 3) {
                Double d = 0.0;
                Double[] values = new Double[3];
                Double v = 0.0;
                while (sT.hasMoreElements()) {
                    String t = sT.nextToken();
                    i++;
                    switch (t) {
                        case "a":
                            v = a;
                            break;
                        case "b":
                            v = b;
                            break;
                        case "c":
                            v = c;
                            break;
                        default:
                            try {
                                v = Double.parseDouble(t);
                            } catch (Exception ex) {
                                v = a;
                            }
                            break;
                    }
                    values[i - 1] = v;
                }

                d = pi * values[0] + psi * values[1] + (zeta / values[2]);
                DecimalFormat format = new DecimalFormat(".###");
                report.getResults().add(""+ pi +"*"+ values[0] +"+"+ psi +"*"+ values[1] +"+("+zeta +"/"+ values[2]+") = "+format.format(d));
                results.add(d);
            } else {
                report.getResults().add("Invalid Entry"+ s);
            }
        }
        return report;
    }

    @Data
    @NoArgsConstructor
    public static class Report {
        String controlRecord;
        List<String> dataSet;
        List<String> results;
        public String toString(){

            String s = controlRecord+"\n";
            s+="Results \n";
            for(String t:results){
                s+=t+"\n";
            }return s;

        }
    }
}
